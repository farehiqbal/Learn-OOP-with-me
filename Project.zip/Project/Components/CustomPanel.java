package Project.Components;

import java.awt.Color;

import javax.swing.*;

public class CustomPanel extends JPanel{

    public CustomPanel(){
        setBackground(Color.DARK_GRAY);

    }
}
