package Project.Products;

public abstract class Product {
    
    protected double price;
    protected String description;
    
}
