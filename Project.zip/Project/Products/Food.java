package Project.Products;

public class Food extends Product{
    GoodsType type;
}  
