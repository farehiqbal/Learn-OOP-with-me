package Project.Products;

public class Chicken extends Meat{
    

    public Chicken(int _weight, Date expiry, double _price){
        this.weight = _weight;
        this.expiryDate = expiry;
        this.price = _price;
    }

    public String getDescription(){
        return "Chicken breast";
    }

    @Override
    public String toString() {
        return "Chicken []";
    }

    
    

}
