package Project.Products;

public enum GoodsType { 
    PERISHABLE, 
    NONPERISHABLE 
};