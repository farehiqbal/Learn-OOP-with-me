package Project;

import Project.Panels.LoginPanel;

public class Main {
    
    public static void main(String[] args) {
        
        LoginPanel loginForm = new LoginPanel();
        loginForm.setVisible(true);
    }
}
